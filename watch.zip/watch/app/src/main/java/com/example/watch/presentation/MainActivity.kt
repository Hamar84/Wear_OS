package com.example.watch.presentation

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text
import com.example.watch.presentation.theme.WatchTheme
import com.google.firebase.database.FirebaseDatabase
import android.widget.Toast
import android.location.Location
import android.os.PowerManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.text.SimpleDateFormat
import java.util.*


class MainActivity : ComponentActivity() {

    private lateinit var sensorManager: SensorManager
    private var heartRateSensor: Sensor? = null
    private var heartRateRecords = mutableListOf<Map<String, Any>>()
    private var maxHeartRate = 0f
    private var minHeartRate: Float = Float.MAX_VALUE
    private var locations = mutableListOf<Map<String, Any>>()

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private lateinit var wakelock: PowerManager.WakeLock

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BODY_SENSORS), 0)
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }

        val powermanager = getSystemService(POWER_SERVICE) as PowerManager
        wakelock = powermanager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Teraz: Beží moja aplikácia")
        wakelock.acquire()

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        heartRateSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE)
        if (heartRateSensor == null) {
            showToast("Nenašiel sa žiadny snímač srdcového tepu!")
        }

        setContent {
            WatchTheme {
                val heartRate by remember { mutableStateOf(0f) }
                HeartRateDisplay(heartRate = heartRate)
            }
        }

        val heartRateSensorListener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type == Sensor.TYPE_HEART_RATE) {
                    val newHeartRate = event.values[0]
                    getCurrentLocation();
                    showToast("Srdcový tep: $newHeartRate")
                    updateHeartRateRecords(newHeartRate)
                    uploadCurrentHeartRate(newHeartRate);
                }
            }
            override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
            }
        }
        sensorManager.registerListener(heartRateSensorListener, heartRateSensor, SensorManager.SENSOR_DELAY_NORMAL)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
    }
    private fun getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            showToast("Oprávnenie na prístup k polohe nebolo udelené")
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            location?.let {
                val lat = it.latitude
                val lng = it.longitude
                val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(
                    Date()
                )
                val locationData = mapOf(
                    "latitude" to lat,
                    "longitude" to lng,
                    "timestamp" to timestamp
            )
                locations.add(locationData)
                uploadToFirebaseWithLocation(lat, lng, timestamp)
            }
        }
    }

    private fun updateHeartRateRecords(newHeartRate: Float) {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        dateFormat.timeZone = TimeZone.getDefault()

        val date = Date()
        val timestamp = dateFormat.format(date)

        maxHeartRate = maxOf(maxHeartRate, newHeartRate)

        if (newHeartRate > 0) {
            minHeartRate = minOf(minHeartRate, newHeartRate)
        }

        val heartRateRecord = mapOf(
            "heartRate" to newHeartRate,
            "timestamp" to timestamp
        )
        heartRateRecords.add(heartRateRecord)

        val database = FirebaseDatabase.getInstance()
        val heartRateRef = database.getReference("heart_rate_data")
        val heartRateData = mapOf(
            "records" to heartRateRecords,
            "max" to maxHeartRate,
            "min" to minHeartRate
        )

        heartRateRef.setValue(heartRateData)
            .addOnSuccessListener {
                showToast("Údaje o srdcovej frekvencii boli úspešne aktualizované")
            }.addOnFailureListener { e ->
                showToast("Aktualizácia údajov o srdcovej frekvencii zlyhala: ${e.message}")
            }
    }

    private fun uploadCurrentHeartRate(heartRate: Float) {
        val database = FirebaseDatabase.getInstance()
        val currentHeartRateRef = database.getReference("heart_rate_data/current")
        currentHeartRateRef.setValue(heartRate)
            .addOnSuccessListener {
                showToast("Aktuálna srdcová frekvencia úspešne aktualizovaná do databázy Firebase")
            }
            .addOnFailureListener { e ->
                showToast("Nepodarilo sa aktualizovať aktuálnu srdcovú frekvenciu do databázy Firebase: ${e.message}")
            }
    }

    private fun uploadToFirebaseWithLocation(latitude: Double, longitude: Double, timestamp: String) {
        val database = FirebaseDatabase.getInstance()
        val locationRef = database.getReference("CurrentLocation").push()
        val locationData = mapOf(
            "latitude" to latitude,
            "longitude" to longitude,
            "timestamp" to timestamp
        )

        locationRef.setValue(locationData)
            .addOnSuccessListener {
                showToast("Úspešná aktualizácia údajov GPS")
            }.addOnFailureListener { e ->
                showToast("Aktualizácia údajov GPS zlyhala: ${e.message}")
            }
    }


    private fun showToast(message: String) {
        runOnUiThread {
            Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if(wakelock.isHeld){
            wakelock.release()
        }
    }
    @Composable
    fun HeartRateDisplay(heartRate: Float) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                text = if (heartRate > 0) "Heart Rate: $heartRate bpm" else "Waiting for heart rate...",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.body1
            )
        }
    }
}
